# 🥦 Lucky Fresh Mart – Complete Website

## 📁 Project Structure
```
lucky-fresh-mart/
├── public/                 ← Main website files
│   ├── index.html          ← Homepage (SEO optimized)
│   ├── css/
│   │   └── style.css       ← All styles
│   └── js/
│       ├── data.js         ← Product & offer data
│       └── app.js          ← Cart, WhatsApp, filters
├── admin/
│   └── index.html          ← Admin dashboard
├── server/
│   └── server.js           ← Node.js server
├── package.json
└── README.md
```

---

## ⚡ Quick Start (Local)

```bash
# 1. Install (no npm packages needed!)
# Just run:
node server/server.js

# 2. Open your browser:
# Website: http://localhost:3000
# Admin:   http://localhost:3000/admin
```

**Default Admin Login:**
- Username: `admin`
- Password: `admin123`

---

## 📱 First Things to Set Up

### 1. Update WhatsApp Number
Open `public/js/app.js` and change line 5:
```js
const WHATSAPP_NUMBER = "91XXXXXXXXXX"; 
// Change to your number e.g. "919876543210"
```

Also update it in `public/index.html` in the `<a href="https://wa.me/91XXXXXXXXXX">` links.

### 2. Update Phone Number in HTML
Search and replace `+91-XXXXXXXXXX` in `public/index.html` with your actual number.

### 3. Update Google Maps
In `public/index.html`, find the `<iframe>` with Google Maps and replace the `src` URL with your actual shop location embed URL from [Google Maps](https://maps.google.com).

---

## 🚀 Deployment Options

### Option A: Netlify (FREE – Recommended)
1. Create account at [netlify.com](https://netlify.com)
2. Drag and drop the `public/` folder into Netlify
3. Your site is live! (e.g. `lucky-fresh-mart.netlify.app`)
4. For admin, also upload the `admin/` folder

### Option B: Vercel (FREE)
```bash
npm install -g vercel
vercel --prod
```

### Option C: GitHub Pages (FREE)
1. Push code to GitHub
2. Settings → Pages → Deploy from `main` branch `/public` folder

### Option D: Hostinger / cPanel (Paid – Best for custom domain)
1. Buy hosting + domain (e.g. `luckyfreshmart.in`)
2. Upload contents of `public/` to `public_html/`
3. Upload `admin/` to `public_html/admin/`

---

## 💰 Pricing Strategy & Business Tips

### Setting Your Vegetable Prices
| Strategy | Formula | Example |
|----------|---------|---------|
| Market Price + Margin | Cost × 1.25 | ₹32 cost → sell at ₹40 |
| Premium Fresh | Cost × 1.40 | ₹32 cost → sell at ₹45 |
| Competitive | Match market -5% | Market ₹40 → sell ₹38 |

**Recommended margins:**
- Leafy greens: 30–40% margin (fast selling, daily fresh)
- Roots (onion/potato): 15–20% margin (high competition)
- Exotic (broccoli, zucchini): 40–50% margin (less competition)

### Daily Offer Strategy
- Run 2–4 daily deals with 25–40% discount
- Use offers on items you have excess stock of
- Feature seasonal vegetables as "specials"
- Rotate offers daily to keep customers coming back

---

## 📈 Pitching to Customers & Getting Orders

### WhatsApp Marketing Script
Send this to your existing customers:
```
🥦 *Lucky Fresh Mart – Now Online!*

Hi [Name]! We've launched our new website:
👉 luckyfreshmart.in

✅ Browse fresh vegetables & prices
🛒 Add to cart & order via WhatsApp
🔥 Daily deals & discounts

Today's Special: Tomatoes at ₹30/kg (was ₹50)!
```

### Getting Google Reviews
1. Ask satisfied customers to review on Google
2. Share your Google Maps link via WhatsApp
3. Aim for 10+ reviews in the first month

### Social Media Tips
- Post "morning stock" photos on Instagram Stories daily
- WhatsApp Status: Post your daily offers every morning at 7 AM
- Create a WhatsApp Broadcast list of regular customers

---

## 🔧 Admin Panel Features

| Feature | Location |
|---------|---------|
| Add/remove vegetables | Admin → Products |
| Update prices (inline) | Admin → Products → Price column |
| Add daily offers | Admin → Offers |
| Change login password | Admin → Settings |
| View shop stats | Admin → Dashboard |

---

## 🆘 Support & Customization

To customize colors: edit the `:root` variables in `public/css/style.css`
To add more products: edit `DEFAULT_PRODUCTS` in `public/js/data.js`
To change shop name: search & replace "Lucky Fresh Mart" across all HTML files

---

*Built for Lucky Fresh Mart, HMT Layout, Bengaluru*
